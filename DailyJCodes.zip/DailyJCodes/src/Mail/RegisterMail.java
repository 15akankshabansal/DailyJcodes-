package Mail;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

class BabyOfAuthenticator extends Authenticator
{
	@Override
	public PasswordAuthentication getPasswordAuthentication() 
	{
		// CREATE object of passwordauthentication
		PasswordAuthentication authentication = new PasswordAuthentication
				("mailmatsendkaro@gmail.com","Simple@1234");
		
		// return the object
		return authentication;
	}
}

public class RegisterMail {
	public static void sendMail(String password, String idss ,String name) {
		try 
		{
		// create object of properties to provide the email-provider
		Properties p = new Properties();
		
		// provide information about service provider
		p.put("mail.smtp.host","smtp.gmail.com");
		p.put("mail.smtp.port","587");
		p.put("mail.smtp.starttls.enable","true");
		p.put("mail.smtp.auth","true");
		
		// create object of authenticator
		BabyOfAuthenticator authenticator = new BabyOfAuthenticator();
		
		// get the object of session
		Session session = Session.getInstance
				(p,authenticator);
		
		// get the message to be sent in this session
		MimeMessage message = new MimeMessage(session);
	
		
		// convert the address into the format understandable by the
		// network
		InternetAddress[] address = {new InternetAddress(idss)};
		
		// set the RCPNT and its type
		message.setRecipients(RecipientType.TO, address);
		
		// set the subject 
		message.setSubject("Password Conformation Cetpa Infotech Pvt. Ltd.");
		
		// set the body part
		message.setContent("<h3>Hello <b><i>"+name+",</i></b></h3><b>Now you are a Authorised user</b><h1>your Password is </h1><h2 style='color: green;'>"+password+"</h2>", 
				"text/html");
		
		// send this mail to the server (email service provider)
		Transport.send(message);
		
		System.out.println("OK\nmail sent");
		
		
		} 
		catch (Exception e) 
		{
			System.out.println("error in code "+e);
		}
	}
}