package rejoining;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import db.DBConnector;

public class ValidatingSubscription {
	
	public static boolean subscriptionValidator(String email) throws Exception {
		
		boolean validator = false;
		Connection con = DBConnector.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from student where email='"+email+"'");
		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy/mm/dd");
		if(rs.next()) {
			String doj = rs.getString("doj");
			//code for date
			String yearpatt="yyyy";
			SimpleDateFormat sdfy=new SimpleDateFormat(yearpatt);
			String dy=sdfy.format(new java.util.Date());
			String year=dy;
			String monthpatt="MM";
			SimpleDateFormat sdfm=new SimpleDateFormat(monthpatt);
			String dm=sdfm.format(new java.util.Date());
			String month=dm;
			String datepatt="dd";
			SimpleDateFormat sdfd=new SimpleDateFormat(datepatt);
			String dd=sdfd.format(new java.util.Date());
			String date=dd;
			String currentDate=year+"/"+month+"/"+date;
			   Date dateBefore = myFormat.parse(doj);
		       Date dateAfter = myFormat.parse(currentDate);
		       long difference = dateAfter.getTime() - dateBefore.getTime();
		       float daysBetween = TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);
			if(daysBetween>365) {
				validator = true;
			}
		}
		return validator;
	}
}
