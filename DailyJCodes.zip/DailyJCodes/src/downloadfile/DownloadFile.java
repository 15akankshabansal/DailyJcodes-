package downloadfile;

import java.io.FileInputStream;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/download")
public class DownloadFile extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//get the file
		String my_file_name = request.getParameter("filename");
		
		//get the path from session [yaha session aise nikalta h]
		String filepath=request.getParameter("filepath");
		
		
		//get the user choice [kispe usne click kiya]
		String my_choice = request.getParameter("click");
		// System.out.println(my_choice);
			my_choice="";
		//find the file type [kya wo pdf,img,audio]
		//#-1- get the last index of .
		int index = my_file_name.lastIndexOf(".");
		
		//get the extension of file
		String file_extension = my_file_name.substring(index + 1);
		
		//check the type of file
		//application/zip, application/octet-stream, application/x-zip-compressed, multipart/x-zip
		
		if (file_extension.equals("zip")) {
			response.setContentType("application/octet-stream");
			
		}else if (file_extension.equals("java") || file_extension.equals("txt")) {
			//set the mime type for file[mime-->Multi-media Internet mail extension]
			response.setContentType("text");
			
		} else if (file_extension.equals("jpg") || file_extension.equals("png") || file_extension.equals("gif") || file_extension.equals("jpeg")) {
			
			response.setContentType("image/jpeg");
			
		} else if (file_extension.equals("pdf")) {
			
			response.setContentType("application/pdf");
			
		} else if (file_extension.equals("mp4")) {
			
			response.setContentType("video/mp4");
			
		} else if (file_extension.equals("mp3")) {
			
			response.setContentType("audio/wav");
			
		} else if (file_extension.equals("doc") || file_extension.equals("dot")) {
			
			response.setContentType("application/msword");
			
		} else if (file_extension.equals("docx")) {
			
			response.setContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
			
		} else if (file_extension.equals("xls") || file_extension.equals("xlt") || file_extension.equals("xla")) {
			
			response.setContentType("application/vnd.ms-excel");
			
		} else if (file_extension.equals("xlsx")) {
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			
		} else if (file_extension.equals("ppt") || file_extension.equals("pot") || file_extension.equals("pps") ||file_extension.equals("ppa")) {
			
			response.setContentType("application/vnd.ms-powerpoint");
			
		} else if (file_extension.equals("pptx")) {
			
			response.setContentType("application/vnd.openxmlformats-officedocument.presentationml.presentation");
			
		}
		
		
		if (my_choice.equals("view")) {
			response.setHeader("Content-Disposition", " inline; filename="+ my_file_name);
		}
		
		else {
			response.setHeader("Content-Disposition", " attachment; filename="+ my_file_name);
		}
		//add file path with file name  
		FileInputStream fis = new FileInputStream(filepath+"/"+my_file_name);
		ServletOutputStream sos = response.getOutputStream();
		while (true) {
			int var = fis.read();
			if (var == -1)
				break;
			sos.write(var);
		}
		fis.close();
	}
}
