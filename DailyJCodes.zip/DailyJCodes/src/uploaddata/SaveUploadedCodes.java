package uploaddata;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import db.DBConnector;
import zipconverter.ZipDir;

@WebServlet("/SaveUploadedCodes")
public class SaveUploadedCodes extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
   		try {
			response.setContentType("text/html");
			
			PrintWriter writer = response.getWriter();
		
			// check if the form is having multipart data or not
			if (ServletFileUpload.isMultipartContent(request)) {
				// create object of DFIF
				DiskFileItemFactory fileItem = new DiskFileItemFactory();

				// create object of SFU using DFIF
				ServletFileUpload upload = new ServletFileUpload(fileItem);

				// parse the request which is coming from the client into the list of fileitem
				List<FileItem> fileItems = upload.parseRequest(request);
				
				String b_timing="";
				String b_type="";
				String topic="";
				String subject="";
				String notes="";
				String teacher="";
				String technology="";
				String typeofcontent="";
				String filename="";
				String zipDirPath="";
				ArrayList<String> uploadedFileData = new ArrayList<String>();			
				
				//code for date
				String yearpatt="yyyy";
				SimpleDateFormat sdfy=new SimpleDateFormat(yearpatt);
				String dy=sdfy.format(new java.util.Date());
				String year=dy;
				String monthpatt="MM";
				SimpleDateFormat sdfm=new SimpleDateFormat(monthpatt);
				String dm=sdfm.format(new java.util.Date());
				String month=dm;
				String datepatt="dd";
				SimpleDateFormat sdfd=new SimpleDateFormat(datepatt);
				String dd=sdfd.format(new java.util.Date());
				String date=dd;
				
				String currentDate2=year+"-"+month+"-"+date;
				String currentDate = year+"/"+month+"/"+date;
				for (FileItem fileItem2 : fileItems) {
					if(fileItem2.isFormField()) {
						if(fileItem2.getFieldName().equalsIgnoreCase("b_timing")) {
							b_timing=fileItem2.getString();
						}else if(fileItem2.getFieldName().equalsIgnoreCase("available_b_type")) {
							b_type=fileItem2.getString();
						}else if(fileItem2.getFieldName().equalsIgnoreCase("topic")) {
							topic=fileItem2.getString();
						}else if(fileItem2.getFieldName().equalsIgnoreCase("subject")) {
							if (fileItem2.getString().equals("")) {
								subject = "(Subject Not Available)";
							}else {
							subject=fileItem2.getString();
							}
						}else if(fileItem2.getFieldName().equalsIgnoreCase("notes")) {
							notes=fileItem2.getString();
						}else if(fileItem2.getFieldName().equalsIgnoreCase("teacher")) {
							teacher=fileItem2.getString();
						}else if(fileItem2.getFieldName().equalsIgnoreCase("technology")) {
							technology=fileItem2.getString();
						}else if(fileItem2.getFieldName().equalsIgnoreCase("typeofcontent")) {
							typeofcontent=fileItem2.getString();
						}
					}
				}
				
				for (FileItem fileItem2 : fileItems) {
					if (!fileItem2.isFormField()) {
						// denote this path using file class
						String path = getServletContext().getRealPath("ClassCode");

						// writer.print(path+"<br>");
						String mainpath = path.substring(0, path.indexOf(".metadata"))
								.concat(path.substring(path.indexOf("\\", path.indexOf("wtpwebapps")) + 1,
										path.lastIndexOf("\\") + 1))
								.concat("WebContent\\ClassCodes");
						// writer.print(mainpath);
						String innerDirectory = typeofcontent+"_"+topic+"_"+b_timing+"_"+b_type+"_"+currentDate2;
						filename=innerDirectory.concat(".zip");
						//create the directory
						File file2 = new File(mainpath.concat("\\"+innerDirectory));
						System.out.println(	file2.mkdir());
						
						zipDirPath = mainpath.concat("\\"+innerDirectory);
						File file = new File(mainpath.concat("\\"+innerDirectory+"\\").concat(fileItem2.getName()));

						FileOutputStream fos = new FileOutputStream(file);

						// store the file inside this denoted path
						fos.write(fileItem2.get());
						fos.close();
							String FileData=fileItem2.getName();
							uploadedFileData.add(FileData);
					}	
				}
					//create the zip file
					ZipDir.createZipFile(zipDirPath);
					
					//store data into database
				try {
					Connection connection = DBConnector.getConnection();
					String query="insert into class_codes "
							+ "(b_type,"
							+ "b_timing,"
							+ "topic,"
							+ "notes,"
							+ "date,"
							+ "filename,"
							+ "teacher,"
							+ "technology,"
							+ "subject)"
							+ " values(?,?,?,?,?,?,?,?,?)";
					PreparedStatement statement = connection.prepareStatement(query);
					statement.setString(1, b_type);
					statement.setString(2, b_timing);
					statement.setString(3, topic);
					statement.setString(4, notes);
					statement.setString(5, currentDate);
					statement.setString(6, filename);
					statement.setString(7, teacher);
					statement.setString(8, technology);
					statement.setString(9, subject);
					statement.executeUpdate();
					
					
					//add files to filedata table
					String query2="insert into filedata "
							+ "(b_type,"
							+ "b_timing,"
							+ "topic,"
							+ "filename,"
							+ "filedata,"
							+ "date,"
							+ "teacher,"
							+ "technology,"
							+ "subject)"
							+ " values(?,?,?,?,?,?,?,?,?)";
					
					for(String fileData : uploadedFileData) {
						PreparedStatement statement2 = connection.prepareStatement(query2);
							statement2.setString(1, b_type);
							statement2.setString(2, b_timing);
							statement2.setString(3, topic);
							statement2.setString(4, filename);
							statement2.setString(5, fileData);
							statement2.setString(6, currentDate);
							statement2.setString(7, teacher);
							statement2.setString(8, technology);
							statement2.setString(9, subject);
							statement2.executeUpdate();
					}
					
					connection.close();
					System.out.println("Code Uploaded");
					writer.print("<script>");
					writer.print("alert(\"Code Uploaded\");");
					writer.print("window.location=\"dashboard_admin.jsp\"");
					writer.print("</script>");
				} catch (Exception e) 
				{
				e.printStackTrace();	
				}
				
			} else {
				writer.print("no multipart content in form");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
