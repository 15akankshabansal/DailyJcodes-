package zipconverter;

import java.io.*;
import java.nio.file.*;
import java.util.zip.*;
import java.nio.file.attribute.*;
 

public class ZipDir extends SimpleFileVisitor<Path> {
 
    private static ZipOutputStream zos;
 
    private Path sourceDir;
 
    public ZipDir(Path sourceDir) {
        this.sourceDir = sourceDir;
    }
 
    @Override
    public FileVisitResult visitFile(Path file, BasicFileAttributes attributes) {
 
        try {
            Path targetFile = sourceDir.relativize(file);
 
            ZipDir.zos.putNextEntry(new ZipEntry(targetFile.toString()));
 
            byte[] bytes = Files.readAllBytes(file);
            
            ZipDir.zos.write(bytes, 0, bytes.length);
            
            ZipDir.zos.closeEntry();
 
        } catch (IOException ex) {
            System.err.println(ex);
        }
 
        return FileVisitResult.CONTINUE;
    }
 
    public static void createZipFile(String dirPath) {
        
    	Path sourceDir = Paths.get(dirPath);
    	
    	try {
            String zipFileName = dirPath.concat(".zip");
            
            ZipDir.zos = new ZipOutputStream(new FileOutputStream(zipFileName));
 
            Files.walkFileTree(sourceDir, new ZipDir(sourceDir));
 
            ZipDir.zos.close();
            
        } catch (IOException ex) {
            System.err.println("I/O Error: " + ex);
        }
    }
}