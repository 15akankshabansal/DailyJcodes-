public class TestGarbageCollection 
{
	public static void main(String[] args) 
	{
	// create some objects of foo class
	Foo f1 = new Foo();
	
	Foo f2 = new Foo();
	
	Foo f3 = new Foo();
	
	Foo f4 = f2;
	
	f2 = null; // object at line#11 will become unused here
	
	f4 = new Foo();
	
	System.gc(); // request JVM to perform garbage collection

	System.out.println("...done");
	}
}
