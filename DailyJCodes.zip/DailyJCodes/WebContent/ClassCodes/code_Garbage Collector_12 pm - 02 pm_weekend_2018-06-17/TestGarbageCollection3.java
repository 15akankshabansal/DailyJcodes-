public class TestGarbageCollection3 
{	
	static void bujhoTohJaane()
	{
		Foo f1 = new Foo();
		Foo f2 = new Foo();
		Foo f3 = new Foo();
	}
	
	public static void main(String[] args) 
	{
	
	TestGarbageCollection3.bujhoTohJaane();	

	System.gc(); // request JVM to perform garbage collection
	
	System.out.println("...done");
	
	}
}