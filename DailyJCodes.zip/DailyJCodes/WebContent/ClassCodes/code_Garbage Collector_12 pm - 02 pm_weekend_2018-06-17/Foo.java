











public class Foo 
{
	// override the finalize() method of Object class
	public void finalize()
	{
		System.out.println("odi baba, mai toh gayo "+this);
	}
}