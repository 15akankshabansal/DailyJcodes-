public class TestGarbageCollection2 
{
	public static void main(String[] args) 
	{
	// create some objects of foo class
	Foo f1 = new Foo();
		
	Foo f2 = f1;
	
	Foo f3 = f2;
	
	Foo f4 = new Foo();
	
	System.out.printf("%s %s %s %s",f1,f2,f3,f4);
	
	f2 = f4;
	
	f1 = null;
	
	f4 = f1;
	
	f2 = f4;
	
	System.gc(); // request JVM to perform garbage collection

	System.out.println("...done");
	}
}
