public class Fan 
{
	String type;
	String brand;
	int price;
	
	public Fan(String type, String brand, int price) 
	{
		this.type = type;
		this.brand = brand;
		this.price = price;
	}
	
	@Override
	public String toString() {
		String msg = "Fan ->\nType :"+type+"\nBrand :"+brand
				+"\nPrice :"+price+"\n";
		return msg;
	}
	
}
