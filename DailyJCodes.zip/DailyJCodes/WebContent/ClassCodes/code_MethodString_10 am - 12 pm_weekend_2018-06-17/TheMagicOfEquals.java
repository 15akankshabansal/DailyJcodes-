public class TheMagicOfEquals 
{
	public static void main(String[] args) 
	{
		int a = 200;
		int b = 200;
		
		// compare the value of 'a' with 'b'
		System.out.println(a == b);
		
		Integer x = 128;
		Integer y = 128;
		
		// compare the address of 'x' with 'y'
		System.out.println(x == y);
		
		System.out.println(x.equals(y));
		
		Cow c1 = new Cow(100);
		Cow c2 = new Cow(100);
		
		System.out.println(c1 == c2);
		
		System.out.println(c1.equals(c2));
	}
}


class Foo{}
