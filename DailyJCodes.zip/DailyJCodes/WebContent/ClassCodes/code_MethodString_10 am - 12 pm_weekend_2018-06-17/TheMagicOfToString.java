public class TheMagicOfToString 
{
	public static void main(String[] args) 
	{
	// create object of fan
	Fan f1 = new Fan("table", "usha", 2400);
	
	// show f1 using sop
	System.out.println(f1);
	
	// create object of fan
	Fan f2 = new Fan("ceiling", "polar", 3400);
	
	// show f2 using sop
	System.out.println(f2);
	}
}
