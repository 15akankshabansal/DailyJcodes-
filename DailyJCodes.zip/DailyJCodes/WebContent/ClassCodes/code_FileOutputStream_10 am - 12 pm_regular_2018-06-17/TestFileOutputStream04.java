import java.io.FileOutputStream;

public class TestFileOutputStream04 
{
	public static void main(String[] args) 
	{
		try 
		{
		String path = "c:/rasmalyi.txt";
		
		// open file in append mode
		FileOutputStream fo = new FileOutputStream(path, false);
		
		// lets take a data
		String data = "bherry bherry yu mmy";
		
		// convert string into array of byte
		byte[] array = data.getBytes();
		
		// store the data of array inside the file in one go
		// start from index#0
		// no of elements 6
		fo.write(array,0,6);
		
		// close the file, good practice
		
		fo.close();		
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
