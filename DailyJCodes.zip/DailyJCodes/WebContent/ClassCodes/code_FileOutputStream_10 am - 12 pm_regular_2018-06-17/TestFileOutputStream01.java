import java.io.FileOutputStream;

public class TestFileOutputStream01 
{
	public static void main(String[] args) 
	{
		try 
		{
		String path = "c:/barfi.txt";
		
		// open a file in write mode
		
		// false : means write mode
		// true : means append mode
		
		FileOutputStream fo = new FileOutputStream(path, false);
		
		// store some bytes inside the file using write() method
		fo.write(48);
		fo.write(65);
		fo.write(32);
		fo.write(97);		
		fo.write(32 + 32);
		
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
