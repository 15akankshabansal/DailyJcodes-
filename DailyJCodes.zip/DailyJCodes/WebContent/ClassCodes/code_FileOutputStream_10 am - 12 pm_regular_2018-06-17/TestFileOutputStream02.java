import java.io.FileOutputStream;

public class TestFileOutputStream02 
{
	public static void main(String[] args) 
	{
		try 
		{
		String path = "c:/imarti.txt";
		
		// open file in append mode
		FileOutputStream fo = new FileOutputStream(path, false);
		
		// lets take a data
		String data = " main";
		
		// convert string into array of byte
		byte[] array = data.getBytes();
		
		// fetch data from the array
		for (int i = 0; i < array.length; i++) 
		{
			// store the data of ith element of this artau inside the file
			fo.write(array[i]);			
		}
		
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
