import java.io.FileOutputStream;

public class TestFileOutputStream03 
{
	public static void main(String[] args) 
	{
		try 
		{
		String path = "c:/jalebi.txt";
		
		// open file in append mode
		FileOutputStream fo = new FileOutputStream(path, false);
		
		// lets take a data
		String data = "dekho dekho ye hai jalwa";
		
		// convert string into array of byte
		byte[] array = data.getBytes();
		
		// store the data of array inside the file in one go
		fo.write(array);
		
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
