import java.sql.*;
public class TestDBConnection 
{
	public static void main(String[] args) 
	{
		try 
		{
		// 1# load driver class
		Class.forName("com.mysql.jdbc.Driver");
		
		// 2# get connection
		Connection co = DriverManager.getConnection
				("jdbc:mysql://127.0.0.1:3306/jan11", "root", "1234");
		
		System.out.println("connected with MySQL");
			
		// 3# close session
		co.close();			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
