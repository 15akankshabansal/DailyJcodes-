import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
public class FetchFileFromDB
{
	public static void main(String[] args)
	{
		try
		{
		Connection co = DriverManager.getConnection
				("jdbc:mysql://localhost:3306/jan17", "root", "1234");
		
		PreparedStatement ps = co.prepareStatement
				("select filedata from file_keeper where filename = ?");
		
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the file name to be fetched from the DB :");
		String filename = s.nextLine();
		
		
		// provide data in place of ?
		ps.setString(1, filename);
		
		// execute sql query
		ResultSet rs = ps.executeQuery();
		
		// check if there is a record inside RS
		if(rs.next())
		{
			// fetch data from RS and store it inside the object of
			// inputstream class
			InputStream is = rs.getBinaryStream("filedata");
			
			// open file in write mode, inside this file the data of RS will
			// be stored
			FileOutputStream fo = new FileOutputStream
					("d:/db-backup/"+filename);
			
			// fetch a byte from IS and store it inside FOS
			while(true)
			{
				// fetch a byte from IS
				int b = is.read();
				
				// check for end of file
				if(b == -1)
				{
					// go out of loop
					break;
				}
				
				// store this byte 'b' inside the FO
				fo.write(b);
			}
			
			// close the file
			fo.close();
		}
		else
		{
			System.out.println("file not found inside DB my dear");
		}
		
		// close session
		co.close();

			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
