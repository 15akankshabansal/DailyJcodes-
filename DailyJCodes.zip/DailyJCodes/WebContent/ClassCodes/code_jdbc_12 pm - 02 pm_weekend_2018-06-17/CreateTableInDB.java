import java.sql.*;
public class CreateTableInDB
{
	public static void main(String[] args) 
	{
		try 
		{
		// 1# load driver class
		Class.forName("com.mysql.jdbc.Driver");
		
		// 2# get connection
		Connection co = DriverManager.getConnection
				("jdbc:mysql://127.0.0.1:3306/jan11", "root", "1234");
		
		// 3# get statement
		Statement st = co.createStatement();
		
		// 4# execute sql statement
		int r = st.executeUpdate
				("update car set name='Alto K10' where maker='maruti'");
		
		System.out.println(r);
			
		// 5# close session
		co.close();			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
