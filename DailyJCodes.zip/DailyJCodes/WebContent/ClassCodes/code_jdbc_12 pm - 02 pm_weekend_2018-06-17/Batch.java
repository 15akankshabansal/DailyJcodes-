import java.sql.*;
public class Batch 
{
	public static void main(String[] args) 
	{
		try 
		{
			Connection conn = DriverManager.getConnection
					("jdbc:mysql://127.0.0.1:3306/jan13", "root", "1234");
			
			Statement stmt = conn.createStatement();
			
			String sql1 = "insert into car(car_name,car_model,car_maker) "
					+ "values('Verna','2017','Hundai')";
			String sql2 = "update car set car_name='Alto K10' "
					+ " where car_model='2019'";
			String sql3 = "delete from car where car_model='2018'";
			
			// add all the query inside a batch
			stmt.addBatch(sql1);
			stmt.addBatch(sql2);
			stmt.addBatch(sql3);
			
			// execute batch
			int[] acks = stmt.executeBatch();
			
			String[] array = {"insert","update","delete"};
			
			for (int i = 0; i < acks.length; i++) 
			{
				System.out.println(array[i]+" query record affected are "+acks[i]);
			}

			conn.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
