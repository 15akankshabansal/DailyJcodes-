import java.io.FileInputStream;
import java.sql.*;
import java.util.Scanner;

import javax.swing.plaf.metal.MetalIconFactory.FolderIcon16;
public class StoreFileInsideDB
{
	public static void main(String[] args)
	{
		try
		{
		Connection co = DriverManager.getConnection
				("jdbc:mysql://localhost:3306/jan17", "root", "1234");
		
		PreparedStatement ps = co.prepareStatement
				("insert into file_keeper values(?,?,?)");
		
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the file path :");
		String filepath = s.nextLine();
		
		// replace \ with / if any
		filepath = filepath.replace("\\", "/");
		
		// get last index of /
		int i = filepath.lastIndexOf("/");
		
		// get a substring from last index + 1
		String filename = filepath.substring(i + 1); 
		
		// open a file in read mode
		// 'fi' denotes the data of file
		FileInputStream fi = new FileInputStream(filepath);
		
		// get file size
		int filesize = fi.available();
		
		// provide data in place of ?
		ps.setString(1, filename);
		ps.setLong(2, filesize);
		ps.setBinaryStream(3, fi, filesize);
		
		// execute sql query
		ps.executeUpdate();
		
		// close session
		co.close();

		System.out.println("...done");
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
