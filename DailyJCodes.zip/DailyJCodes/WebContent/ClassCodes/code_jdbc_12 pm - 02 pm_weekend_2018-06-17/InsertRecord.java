import java.sql.*;
public class InsertRecord 
{
	public static void main(String[] args) 
	{
		try 
		{
			Connection conn = DriverManager.getConnection
					("jdbc:mysql://127.0.0.1:3306/jan13", "root", "1234");
			
			Statement stmt = conn.createStatement();
			
//			int a1 = stmt.executeUpdate
//			("insert into car (car_name,car_model,car_maker) values"
//					+ "('i10','2016','hundai')");
			
			int carid = 5;
			String cname = "ignis";
			int cmodel = 2017;
			String cmaker = "Maruti Suzuki";
			
			int a2 = stmt.executeUpdate
					("insert into car(car_name,car_model,car_maker) values"
					+ "('"+cname+"','"+cmodel+"','"+cmaker+"')");
			
			System.out.println("ack from db is "+a2);
			
			conn.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
