import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Scanner;

public class DemoRSMD 
{
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		
		System.out.print("Input DB name:");
		String db = s.next();
		
		
		try 
		{
			Connection conn = DriverManager.getConnection
					("jdbc:mysql://127.0.0.1:3306/"+db, "root", "1234");
			
			Statement stmt = conn.createStatement();
			
			System.out.print("Input Table name:");
			String tab = s.next();

			
			ResultSet rs = stmt.executeQuery
					("select * from "+tab);
			
			// get meta data for this RS
			ResultSetMetaData rsmd = rs.getMetaData();
			
			// get no of cols inside RS
			int cols = rsmd.getColumnCount();
			
			System.out.println("cols inside RS are "+cols);
			
			for(int i = 1; i <= cols; i++)
			{
				// get col name of RS
				String colName = rsmd.getColumnName(i);

				// get col type name of RS
				String colType = rsmd.getColumnTypeName(i);
				System.out.println(i+" : "+colName+" : "+colType);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
