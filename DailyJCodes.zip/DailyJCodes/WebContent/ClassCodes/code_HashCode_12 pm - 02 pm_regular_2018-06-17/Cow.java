public class Cow 
{
	int weight;

	public Cow(int weight) 
	{
		this.weight = weight;
	}
	
	// override the hashcode
	@Override
	public int hashCode() 
	{		
		return weight;
	}
	
}
