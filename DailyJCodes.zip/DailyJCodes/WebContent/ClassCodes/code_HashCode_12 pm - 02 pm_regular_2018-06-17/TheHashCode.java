public class TheHashCode 
{
	public static void main(String[] args) 
	{
	// create object of cow
	Cow c1 = new Cow(100); 
	
	// get the hashcode of c1
	int x = c1.hashCode();
	
	System.out.println(x);
	
	// create object of cow
	Cow c2 = new Cow(59); 
	
	// get the hashcode of c2
	int y = c2.hashCode();
	
	System.out.println(y); // show adrs in number
	
	System.out.println(c2); // show adrs in stirng
	
	System.out.println(c1); // show adrs in stirng
	}
}
