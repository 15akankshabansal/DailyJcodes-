
class Cat{}

public class Prove 
{
	public static void main(String[] args) 
	{
	// create object of cat
	Cat c1 = new Cat();
	// fetch the adrs of c1 in string 
	String adrs = c1.toString();	
	System.out.println(adrs);
	
	// create object of cat
	Cat c2 = new Cat();
	// fetch the adrs of c1 in string 
	String adrs2 = c2.toString();	
	System.out.println(adrs2);		
	
	// here the toString() will be invoked automatically
	System.out.println(c1);
	
	// here the toString() is be invoked by us
	System.out.println(c1.toString());
	}
}
