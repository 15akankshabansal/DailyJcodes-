public class TheStringBufferClass001 
{
	public static void main(String[] args) 
	{
		// create an object of string-buffer class
		StringBuffer buf = new StringBuffer();
		
		// store data inside buffer at rear end
		buf.append("p");
		buf.append("r");
		buf.append("t");
		
		// insert 'q' at index 1
		buf.insert(1, "q");
		
		// insert 's' at index 3
		buf.insert(3, "Ts");
		
		// delete all the chars from index#0 to index#3 minus 1
		buf.delete(0, 3);
		
		// reverse the data
		buf.reverse(); buf.reverse();
		
		// put # at index no 0
		buf.setCharAt(0, '#');
		
		// get buffer size
		int c = buf.capacity();
		System.out.println("buffer size is "+c);
		
		// no of char inside buffer
		int e = buf.length();
		System.out.println("elements inside buffer "+e);
		
		// show data
		System.out.println("buffer data is ->"+buf+"<-");
		
		// get fiorst index of 't'
		int i = buf.indexOf("t");
		System.out.println("first index of 't' is "+i);
		
		// assign the object of buffer inside string after conversion
		String str = buf.toString();
		System.out.println("string is "+str);	
		
	}
}

