import java.util.StringTokenizer;

public class StringTokenizer003 
{
	public static void main(String[] args) 
	{
		String text = "the wild tiger is a type of big cat ohh cat";
		String test2 = "ci";
		boolean choice = false;
		
		// create object of string tokenizer in order to divide
		// text into tokens
		StringTokenizer st = new StringTokenizer(text, test2, choice);
		
		// get no of tokens inside ST
		int tok = st.countTokens();
		System.out.println("Tokens inside tokenizer are "+tok);
		
		// fetch tokens from the object of tokenizer
		while(st.hasMoreTokens())
		{
			// fetch a token
			String t= st.nextToken();
			System.out.println(">"+t+"<");
		}
		
		System.out.println(st.countTokens());
	}
}
