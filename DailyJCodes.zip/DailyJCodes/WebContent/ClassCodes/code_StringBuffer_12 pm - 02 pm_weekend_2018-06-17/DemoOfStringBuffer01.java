public class DemoOfStringBuffer01 
{
	public static void main(String[] args) 
	{
	// create object of string buffer class
	StringBuffer buf = new StringBuffer();	
	
	// store data of any type at rear end
	buf.append("b"); // store 'b' at rear end
	buf.append("d"); // store 'd' at rear end
	buf.insert(1, "c"); // store 'c' at index#1 the 'd' will be shifted 
//	// to right hand
	buf.insert(0, "a"); // store 'a' at index#0 the all the data	
//	// will be shifted to right hand
	
	// get buffer size
	int b = buf.capacity();
	System.out.println("buffer size is "+b);
	
	// get no of elements inside buffer
	int e = buf.length();
	System.out.println("elements inside buffer are "+e);
	
	System.out.println("data inside buffer >"+buf+"<");
	
	// get first index of 'd' inside buffer
	int i = buf.indexOf("d");
	System.out.println("first index of 'd' is "+i);
		
	}
}
