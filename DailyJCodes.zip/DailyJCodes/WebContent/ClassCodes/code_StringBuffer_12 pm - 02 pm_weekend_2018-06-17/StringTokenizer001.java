import java.util.StringTokenizer;

public class StringTokenizer001 
{
	public static void main(String[] args) 
	{
		String text = "a b c d e";
		
		// create object of string tokenizer in order to divide
		// text into tokens
		StringTokenizer st = new StringTokenizer(text);
		
		// get no of tokens inside ST
		int tok = st.countTokens();
		System.out.println("Tokens inside tokenizer are "+tok);
		
	}
}
