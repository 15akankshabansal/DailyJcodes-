public class DemoOfStringBuffer02
{
	public static void main(String[] args) 
	{
	// create object of string buffer class
	StringBuffer buf = new StringBuffer();	

	for(int i = 1; i <= 143; i++)
	{
		buf.append(1);
		System.out.println(buf.length()+" : "+buf.capacity());
	}
	
	System.out.println(">>>>>>>>>>>>>>>>>>>>");
	
	// make the size of buffer equal to the elemnets inside
	buf.trimToSize();
	
	System.out.println(buf.length()+" : "+buf.capacity());		
	}
}
