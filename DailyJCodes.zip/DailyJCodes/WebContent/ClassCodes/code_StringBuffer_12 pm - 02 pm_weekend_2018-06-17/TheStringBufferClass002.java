public class TheStringBufferClass002 
{
	public static void main(String[] args) 
	{
		// create an object of string-buffer class
		StringBuffer buf = new StringBuffer();
		
		buf.append("                ");
		
		buf.append(" ");
		
		buf.append("                  ");
		
		// make the buffer size equal to the no of elements inside
		buf.trimToSize();
		
		System.out.println(buf.capacity());
		System.out.println(buf.length());
		
	}
}

