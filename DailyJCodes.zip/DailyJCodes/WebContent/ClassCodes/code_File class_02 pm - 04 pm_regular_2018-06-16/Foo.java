class Foo{

	public static void main(String...a) throws Exception{
	int x=-3;
	String aa="hello";
	//System.out.printf("%s",aa);
	//Thread.sleep(3000);
	//System.out.printf("\n%20s",aa);
	//Thread.sleep(3000);
	System.out.printf("%-20x",x);
	Thread.sleep(3000);
	
	}


}