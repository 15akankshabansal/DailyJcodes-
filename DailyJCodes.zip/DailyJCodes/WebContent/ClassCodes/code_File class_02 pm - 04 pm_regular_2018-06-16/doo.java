class doo{
	public static void main(String...args) throws Exception {
	String a="hello";
	System.out.printf("%-20S",a);
	Thread.sleep(3000);
	}
}