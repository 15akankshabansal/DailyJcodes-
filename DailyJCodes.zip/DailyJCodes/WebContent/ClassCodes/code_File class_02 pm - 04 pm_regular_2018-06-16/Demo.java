class Demo
{
	public staatic void main(String[] args)
	{
		
	
	
	
	}

}