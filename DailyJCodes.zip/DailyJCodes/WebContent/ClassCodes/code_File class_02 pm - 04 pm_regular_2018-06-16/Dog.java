class Dog
{
	public static void main(String[] args)
	{
		Test t=Test.fx();
		Test t1=Test.fx();
		System.out.println(t);
		System.out.println(t1);
		
	}
}
