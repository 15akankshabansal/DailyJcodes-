import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MyUI01 extends JFrame implements ActionListener
{
	JButton b1, b2;
	JTextField tf;
	JPasswordField pf;
	JTextArea area;
	JScrollPane pane;
	JLabel l;
	
	public MyUI01() 
	{
	// provide the title for the frame	
	super.setTitle("signup");	
		
	// provide dimension of frame
	super.setBounds(100, 100, 600, 500);
	
	// make frame not resizable
	super.setResizable(false);
	// ----------------------------------------------------
	
	b1 = new JButton("signup"); // object of button
	b1.setBounds(100, 400, 80, 25); // dim of button
	super.add(b1); // add button to frame
	b1.addActionListener(this); // register button for event handing

	b2 = new JButton("login"); // object of button
	b2.setBounds(200, 400, 80, 25); // dim of button
	super.add(b2); // add button to frame
	b2.addActionListener(this); // register button for event handing

	tf = new JTextField();
	tf.setBounds(100, 100, 200, 20);
	super.add(tf);	
	
	pf = new JPasswordField();
	pf.setBounds(100, 130, 200, 20);
	super.add(pf);
	
	area = new JTextArea();
	pane = new JScrollPane(area);
	pane.setBounds(100, 160, 400, 230);
	super.add(pane);
	
	l = new JLabel("Username");
	l.setBounds(20, 100, 80, 20);
	super.add(l);
	
	// ----------------------------------------------------
	super.setLayout(null);
	// show frame on screen
	super.setVisible(true);	
	// terminate b v vb                                         application when frame is closed 
	super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) 
	{
		// create object of this class
		MyUI01 m = new MyUI01();
	
	}
	
	// define AP() of action-listener interface
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		// it will give the object of button on which we clicked
		if(e.getSource() == b1)
		{
		// fetch data of TF and PF and store it
		String s1 = tf.getText();
		String s2 = pf.getText();
		String s3 = s1 + s2;
		// store this data inside AREA
		area.setText(s3);
		
		System.out.println(s1.length());
		}
		if(e.getSource() == b2)
		{
			String s1 = tf.getText();
			String s2 = pf.getText();
			String s3 = s1;
			s1 = s2;
			s2 = s3;
			tf.setText(s1);
			pf.setText(s2);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
