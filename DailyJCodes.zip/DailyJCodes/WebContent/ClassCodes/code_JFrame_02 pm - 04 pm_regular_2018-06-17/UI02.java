import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
public class UI02 extends JFrame implements ActionListener 
{
	JTextField t1, t2;
	JTextArea area;
	JScrollPane pane;
	JButton b1;
	public UI02() 
	{
	super.setTitle("my-frame-2");	
	super.setBounds(50, 50, 700, 600);
	super.setResizable(false);
	// -------------------------------------------
	t1 = new JTextField();
	t1.setBounds(100, 50, 300, 25);
	super.add(t1);
	
	t2 = new JTextField();
	t2.setBounds(100, 80, 300, 25);
	super.add(t2);
	
	area = new JTextArea();
	pane = new JScrollPane(area);
	pane.setBounds(100, 110, 450, 400);
//	super.add(pane);
	
	b1 = new JButton("click me");
	b1.setBounds(100, 520, 100, 25);
	super.add(b1);
	b1.addActionListener(this);
	// -------------------------------------------
	super.setLayout(null);
	super.setVisible(true);
	super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) 
	{
		UI02 u = new UI02();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == b1)
		{
		
		this.dispose();	
		UI01 u = new UI01();	
			
/*		// create object of file dialog class using Param cnst
		FileDialog fd = new FileDialog(this, "open a file to read", FileDialog.LOAD);
		// show dialog box on frame
		fd.setVisible(true);
		
		// get dir name
		String dir = fd.getDirectory();
		
		// get file name
		String file = fd.getFile();
		
		//JOptionPane.showMessageDialog(this,"DIR =>"+dir+"\nFILE =>"+file);
		
		// store data of dir inside t1
		t1.setText(dir);
		
		// store data of file inside t2
		t2.setText(file);
		
		// create object of font class
		Font f = new Font("", Font.ITALIC, 16);
			
		// apply the font to the area
		area.setFont(f);
	
		// apply a color to the text of text area
		area.setBackground(Color.yellow);
			
		// apply a color to the text of text area
		area.setForeground(Color.blue);
		
		try {
			
		// open a file in read mode	
		FileInputStream fi = new FileInputStream(dir + file);	
		
		String filedata = "";
		
		while(true)
		{
			// fetch a byte from the file and store it
			int var = fi.read();
			
			// check for end of file
			if(var == -1)
			{
				break;
			}
			// convert byte into char
			char ch = (char) var;
			
			// concat the char in string
			filedata = filedata + ch;
		}
			
			
		// store filedata inside area
		area.setText(filedata);
		} catch (Exception e2) {
			// TODO: handle exception
		}
	*/	
		}
	}
}